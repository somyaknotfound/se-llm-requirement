# User stories

## FR-ERX-001

As a prescriber, I want the system to provide a quick and efficient interface for issuing electronic prescriptions, with interaction and allergy check responses coming back within 2 seconds for at least 95% of orders, so that I can issue 60-80 prescriptions per day without significant delays.

```gherkin
Given a prescriber is using the system to issue an electronic prescription
When the system processes the order and checks for drug interactions and allergies
Then the response time should be within 2 seconds for at least 95% of orders
```

## FR-ERX-002

As a prescriber, I want the system to display the patient's active medication list and recorded allergies on the same screen as the order being written, so that I can view the patient's active medications and allergies without having to click or navigate away.

```gherkin
Given a prescriber is writing an electronic prescription for a patient
When the system displays the patient's active medication list and recorded allergies on the same screen as the order being written
Then the prescriber should be able to view the patient's active medications and allergies without having to click or navigate away
```

## FR-ERX-003

As a prescriber, I want the system to provide real-time drug-drug interaction and allergy contraindication checking at the point of ordering, so that prescribers receive alerts for drug interactions and allergies within 2 seconds for at least 95% of orders.

```gherkin
Given a prescriber is using the system to issue an electronic prescription
When the system processes the order and checks for drug interactions and allergies
Then the system should provide real-time alerts for drug interactions and allergies within 2 seconds for at least 95% of orders
```

## FR-ERX-004

As a prescriber, I want the system to transmit electronic prescriptions to community pharmacies through the e-prescribing intermediary, so that prescriptions are transmitted to community pharmacies within 60 seconds if transmission fails, prescribers are notified.

```gherkin
Given a prescriber has issued an electronic prescription
When the system attempts to transmit the prescription to the community pharmacy and fails
Then the system should notify the prescriber and attempt to transmit the prescription again within 60 seconds
```

## FR-ERX-005

As a prescriber, I want the system to generate a prescription with the required fields when a prescriber requests an e-Rx, so that the generated prescription includes patient's name, date of birth, medication details, and number of refills authorized.

```gherkin
Given a prescriber is using the system to request an electronic prescription
When the system generates the prescription
Then the generated prescription should include the patient's name, date of birth, medication details, and number of refills authorized
```

## FR-ERX-006

As a prescriber, I want the system to send the prescription details to the community pharmacy for filling, so that prescription details, including medication name, strength, dose form, quantity, and directions for use, are transmitted to the community pharmacy.

```gherkin
Given a prescriber has issued an electronic prescription
When the system transmits the prescription details to the community pharmacy
Then the prescription details, including medication name, strength, dose form, quantity, and directions for use, should be transmitted to the community pharmacy
```

## FR-ERX-008

As a system, I want to check the formulary before issuing a prescription, so that the issuance of prescriptions for medications not on the formulary is prevented.

```gherkin
Given a request to issue a prescription for a medication not on the formulary, When the system checks the formulary, Then the system prevents the issuance of the prescription.
```

## FR-ERX-009

As a system, I want to transmit prescriptions with community pharmacies through the e-prescribing intermediary, so that every prescription arrives with the required data fields present.

```gherkin
Given a prescription request with all required data fields, When the system transmits the prescription through the e-prescribing intermediary, Then the prescription arrives at the community pharmacy with all required data fields present.
```

## FR-ERX-010

As a system, I want to include the number of refills authorized in the prescription details sent to the community pharmacy, so that the number of refills is included in the prescription details.

```gherkin
Given a prescription request with a specified number of refills, When the system transmits the prescription through the e-prescribing intermediary, Then the number of refills authorized is included in the prescription details transmitted to the community pharmacy.
```

## FR-ERX-011

As a system, I want to include the override reason with the prescription when a prescriber overrides an interaction alert, so that the override reason is included in the prescription details transmitted to the community pharmacy.

```gherkin
Given a prescription request where a prescriber overrides an interaction alert and provides an override reason, When the system transmits the prescription through the e-prescribing intermediary, Then the override reason is included in the prescription details transmitted to the community pharmacy.
```

## FR-ERX-012

As a system, I want to check for drug-drug interactions and allergies before issuing a prescription, so that an alert is displayed to the prescriber if an interaction or allergy is detected.

```gherkin
Given a request to issue a prescription that may cause a drug-drug interaction or an allergy, When the system checks for interactions and allergies, Then the system displays an alert to the prescriber.
```

## FR-ERX-013

As a system, I want to display an alert to the prescriber if an interaction or allergy is detected, so that the prescriber receives a visible and audible alert when an interaction or allergy is detected.

```gherkin
Given a request to issue a prescription that may cause a drug-drug interaction or an allergy, When the system detects an interaction or allergy, Then the prescriber receives a visible and audible alert.
```

## FR-ERX-014

As a system administrator, I want the system to record the reason for any override of an interaction or allergy alert, so that the prescriber's rationale is documented.

```gherkin
Given a high-severity drug-drug interaction alert, When the prescriber overrides the alert, Then the system logs the reason provided by the prescriber.
```

## FR-ERX-016

As an administrator appointed by the pharmacy and therapeutics committee, I want to be able to change interaction severity levels, so that the system can reflect the correct risk level of drug interactions.

```gherkin
Given a user is not an administrator appointed by the pharmacy and therapeutics committee, When they attempt to change the severity level of an interaction alert, Then the system denies their request.
Given a user is an administrator appointed by the pharmacy and therapeutics committee, When they change the severity level of an interaction alert, Then the system updates the severity level accordingly.
```

## FR-ERX-017

As a prescriber, I want to request an override of standard scheduling protocols, so that I can accommodate specific patient needs.

```gherkin
Given a prescriber wants to override the standard scheduling protocol for a medication, When they request an override, Then the system records the reason for the override.
```

## FR-ERX-019

As a system administrator, I want the system to be certified against the ONC criteria for CPOE medications, drug-drug and drug-allergy interaction checks, and electronic prescribing, so that the system meets regulatory standards.

```gherkin
Given the system is being tested for certification against the ONC criteria, When the tests are run, Then the system passes all required checks for CPOE medications, drug-drug and drug-allergy interaction checks, and electronic prescribing.
```

## FR-ERX-020

As a system administrator, I want the system to perform formulary checking by calling the payer formulary service and continue ordering if it does not answer within 3 seconds, so that the system can ensure compliance with payer policies.

```gherkin
Given the payer formulary service does not respond within 3 seconds, When the system attempts to call the service for formulary checking, Then the system continues the order process.
```

## FR-ERX-021

As a pharmacist, I want the system to ensure that a user's prescription of oral liquid medications is limited to metric standard units of mL, so that the prescription is accurate and consistent.

```gherkin
Given a user attempts to prescribe an oral liquid medication in non-metric units, When the system processes the prescription, Then it rejects the prescription and requests the use of metric units (mL).
```

## FR-ERX-022

As a system, I want to insert leading zeroes before the decimal point for amounts less than one when prescribing medications, so that the system formats medication amounts according to the specified rules.

```gherkin
Given a medication amount of 0.5, When the system formats the amount, Then the formatted amount should be '0.5'
Given a medication amount of 0.02, When the system formats the amount, Then the formatted amount should be '0.02'
```

## FR-ERX-024

As a prescriber, I want to override drug-drug interaction and allergy contraindication alerts, with the reason for the override recorded, so that I can manage patient care effectively.

```gherkin
Given an alert about a drug-drug interaction, When the prescriber overrides the alert, Then the system should record the reason for the override
Given an alert about an allergy contraindication, When the prescriber overrides the alert, Then the system should record the reason for the override
```

## FR-ERX-025

As a system, I want to ensure that pharmacies are informed of prescription cancellations, so that pharmacies can update their records accordingly.

```gherkin
Given a prescription cancellation request, When the system processes the request, Then it should notify the relevant pharmacy
```

## FR-ERX-027

As a system, I want to support real-time communication of prescription change requests and responses, so that changes can be communicated promptly.

```gherkin
Given a prescription change request, When the system receives the request, Then it should transmit the request in real-time to the relevant parties
Given a prescription change response, When the system receives the response, Then it should transmit the response in real-time to the relevant parties
```

## FR-ERX-028

As a system, I want to support the real-time transmission of prescription cancellation requests and responses to meet the deadline for eliminating faxed and paper prescriptions, so that the process is efficient.

```gherkin
Given a prescription cancellation request, When the system receives the request, Then it should transmit the request in real-time to the relevant parties
Given a prescription cancellation response, When the system receives the response, Then it should transmit the response in real-time to the relevant parties
```

## FR-ERX-029

As a system, I want to ensure the real-time transmission of medication history requests and responses, so that the medication history is up-to-date.

```gherkin
Given a medication history request, When the system receives the request, Then it should transmit the request in real-time to the relevant parties
Given a medication history response, When the system receives the response, Then it should transmit the response in real-time to the relevant parties
```

## FR-ERX-030

As a prescriber, I want the system to review every interaction and allergy alert presented at the time of ordering, so that I can ensure patient safety.

```gherkin
Given a prescriber is ordering a medication, When an interaction or allergy alert is presented, Then the system must prompt the prescriber to review it before finalizing the order.
```

## FR-ERX-031

As a prescriber, I want the system to require a documented reason for overriding an alert, so that I can justify my decision and ensure patient safety.

```gherkin
Given a prescriber is overriding an allergy alert, When they attempt to finalize the order, Then the system must prompt them to provide a documented reason.
Given a prescriber has provided a documented reason, When they override an alert, Then the system must record this reason with the order.
```

## FR-ERX-032

As a system, I want to flag duplicate therapy to the prescriber before signing a medication order, so that I can prevent potential drug interactions and ensure patient safety.

```gherkin
Given a prescriber is ordering a medication, When there are two active orders for drugs in the same therapeutic class, Then the system must alert the prescriber before the order is signed.
```

## FR-ERX-033

As a system, I want to support the creation, change, and cancellation of prescriptions to ensure compliance with clinical safety policies, so that I can maintain patient safety.

```gherkin
Given a prescriber is creating a new prescription, When they follow S-CSO-10 guidelines, Then the system must allow the creation of the prescription.
Given a prescriber is changing an existing prescription, When they follow S-CSO-10 guidelines, Then the system must allow the change of the prescription.
Given a prescriber is canceling an existing prescription, When they follow S-CSO-10 guidelines, Then the system must allow the cancellation of the prescription.
```

## FR-ERX-034

As a system, I want to notify the prescriber in real-time when a prescription is cancelled, and this notification must be delivered within 90 seconds, so that I can ensure the prescriber is aware of changes.

```gherkin
Given a prescription is cancelled, When the cancellation is processed, Then the system must send an electronic notification to the prescriber within 90 seconds.
Given the prescriber receives the notification, When they acknowledge receipt, Then the system must record the acknowledgment.
```

## FR-ERX-035

As a system, I want to ensure that prescriptions include the number of refills, so that I can prevent errors and ensure patient safety.

```gherkin
Given a prescriber is creating a new prescription, When they do not provide the refill count, Then the system must prompt them to provide this information.
Given a prescriber has provided the refill count, When they finalize the order, Then the system must include the refill count in the prescription.
```

## FR-ERX-036

As a prescriber, I want the system to allow me to indicate whether a generic substitution is allowed, so that the pharmacy receives this information with the prescription.

```gherkin
Given the prescriber is logged into the system
When the prescriber opens a new prescription form
Then the system should prompt the prescriber to specify substitution preferences
Given the prescriber has specified substitution preferences
When the prescriber submits the prescription
Then the pharmacy should receive this information with the prescription
```

## FR-ERX-037

As a system administrator, I want the system to record security- and privacy-relevant events as AuditEvent resources; treat HTTP logs as being as sensitive as the resources themselves, so that all e-Rx issuance activities are securely logged.

```gherkin
Given an e-Rx issuance activity is performed
When the system records the event
Then an AuditEvent resource should be created
Given an e-Rx issuance activity is performed
When HTTP logs related to this activity are generated
Then these logs should be stored securely and treated with the same level of confidentiality as the prescription data
```

