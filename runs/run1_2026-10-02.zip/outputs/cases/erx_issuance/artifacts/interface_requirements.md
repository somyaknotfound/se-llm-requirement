# Interface requirements

| Requirement | Statement | Acceptance criteria | Sources |
|---|---|---|---|
| FR-ERX-004 | The system shall transmit electronic prescriptions to community pharmacies through the e-prescribing intermediary. | Prescriptions are transmitted to community pharmacies within 60 seconds if transmission fails, prescribers are notified. | S-PRES-05 |
| FR-ERX-006 | The system shall send the prescription details to the community pharmacy for filling. | Prescription details, including medication name, strength, dose form, quantity, and directions for use, are transmitted to the community pharmacy. | S-PHARM-01; S-PHARM-02 |
| FR-ERX-009 | The system shall transmit prescriptions with community pharmacies through the e-prescribing intermediary, ensuring that every prescription arrives with the required data fields such as drug name, strength, dose form, quantity, directions for use, and the number of refills authorised. | Prescriptions are transmitted to community pharmacies through the e-prescribing intermediary with all required data fields present. | S-PHARM-01; S-PHARM-09 |
| NFR-ERX-008 | The system shall exchange orders over HL7 v2 and publish each order as a FHIR R4 MedicationRequest through an adapter. | The system exchanges orders over HL7 v2 and publishes each order as a FHIR R4 MedicationRequest through an adapter. | S-ARCH-01; S-ARCH-03; S-ARCH-12; S-ARCH-15 |
| NFR-ERX-013 | The system shall transmit electronic prescriptions to community pharmacies through an e-prescribing intermediary. | Prescriptions are transmitted to pharmacies via the intermediary. | DOC-KICKOFF#p2 |
| FR-ERX-027 | The system shall support real-time communication of prescription change requests and responses. | Prescription change requests and responses are transmitted in real-time. | DOC-KICKOFF#p2; S-PO-10; S-PO-17 |
| FR-ERX-028 | The system shall support the real-time transmission of prescription cancellation requests and responses to meet the deadline for eliminating faxed and paper prescriptions. | Prescription cancellation requests and responses are transmitted in real-time. | DOC-KICKOFF#p2; S-PO-11; S-PO-18 |
