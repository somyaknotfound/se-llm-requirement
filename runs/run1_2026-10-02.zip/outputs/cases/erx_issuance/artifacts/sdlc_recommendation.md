# SDLC recommendation

**Recommended:** Waterfall (79.2%) — runner-up V-Model. Status: pending approval by project manager, architect, security officer, compliance officer.

| Rank | Model | Suitability | Supporting rules |
|---|---|---|---|
| 1 | Waterfall | 79.2% | R-WF |
| 2 | V-Model | 77.5% | R-V |
| 3 | Hybrid | 68.8% | — |
| 4 | Spiral | 55.0% | — |
| 5 | DevSecOps | 54.2% | — |
| 6 | Agile | 35.4% | — |

## Decision factors (median of both models)

| Factor | Score |
|---|---|
| requirement_instability | 1 |
| regulatory_criticality | 4.5 |
| security_risk | 4.5 |
| project_complexity | 3.5 |
| system_size | 4 |
| legacy_dependence | 3 |
| change_frequency | 2 |
| continuous_delivery_need | 3 |
| stakeholder_availability | 4 |
| documentation_rigour | 4.5 |
| schedule_budget_rigidity | 4.5 |
| formal_verification_need | 4 |
| failure_consequence | 4 |

Contested (models differ by 2+ points): system_size, legacy_dependence, continuous_delivery_need, stakeholder_availability, formal_verification_need, failure_consequence

**Escalated:** near tie: Waterfall 79.2% vs V-Model 77.5%; the two models disagree by 2+ points on: system_size, legacy_dependence, continuous_delivery_need, stakeholder_availability, formal_verification_need, failure_consequence

## Justification

Waterfall ranks first for this project due to its stable requirements and extensive approvals, which align with the project's fixed go-live date and regulatory calendar. The V-Model is the runner-up because it emphasizes strict verification and validation, crucial for handling sensitive patient data and ensuring regulatory compliance. Both models are suitable given the project's complexity and regulatory criticality.

Strongest argument against: While Waterfall ensures stable requirements, it may not be as flexible in adapting to changes, which could be a drawback given the project's complexity and need for integration with multiple systems.


## Project workflow — Waterfall

| # | Phase | Activities | Roles | Deliverables | Security | Compliance checkpoints | Exit criterion | Approval gate |
|---|---|---|---|---|---|---|---|---|
| 1 | Initiation | Define scope and objectives; Select SDLC and plan | project_manager, product_owner | Project charter; SDLC decision record |  |  | Charter and SDLC decision approved | project_manager, architect, security_officer, compliance_officer (RTM checked) |
| 2 | Requirements | Elicit and analyse requirements; Baseline the SRS; Clinical hazard identification | business_analyst, product_owner, compliance_officer | SRS baseline; Traceability matrix |  | HIPAA risk analysis completed and approved (45 CFR 164.308(a)(1)(ii)(A)) | SRS baselined | product_owner, compliance_officer (RTM checked) |
| 3 | Design | Architecture and detailed design | architect | Design specification | Threat modelling (STRIDE) of the functionality; Security requirements review |  | Design approved | architect, security_officer (RTM checked) |
| 4 | Implementation | Build to the design; Unit test | developer | Code; Unit test results | Static application security testing on every build; Dependency and secret scanning |  | Code complete |  |
| 5 | Verification | Integration and system test against the SRS | tester | Test report | Dynamic application security testing; Penetration test before release |  | All requirements verified |  |
| 6 | Deployment | Release and hand-over; Clinical safety case approved | operations, project_manager | Release notes | Security sign-off | ONC certification testing passed for the applicable 45 CFR 170.315 criteria; Third-party EPCS audit or certification passed before use (21 CFR 1311.300) | Accepted into service | project_manager, clinical_safety_officer, security_officer, compliance_officer (RTM checked) |
| 7 | Maintenance | Corrective maintenance; Change control | operations | Change log | Security monitoring and incident response; Vulnerability patching to an agreed timescale | Security documentation retained for 6 years (45 CFR 164.316(b)(2)(i)); Daily audit-trail analysis with incident reporting within one business day (21 CFR 1311.150); Re-audit when signing functionality changes or every two years (21 CFR 1311.300) | Retirement |  |

```mermaid
flowchart LR
    P0{{"Initiation"}}
    P1{{"Requirements"}}
    P0 --> P1
    P2{{"Design"}}
    P1 --> P2
    P3["Implementation"]
    P2 --> P3
    P4["Verification"]
    P3 --> P4
    P5{{"Deployment"}}
    P4 --> P5
    P6["Maintenance"]
    P5 --> P6
```

## Project-specific activities

- **Initiation:** Identify key stakeholders and their roles in the e-Rx issuance process.
- **Initiation:** Conduct a risk assessment for the implementation of real-time drug-drug interaction and allergy contraindication checking.
- **Requirements:** Develop a prototype for the prescriber interface to validate the quick and efficient order entry process.
- **Requirements:** Conduct user acceptance testing (UAT) with prescribers to ensure the interface meets their needs.
- **Design:** Create a detailed design for the real-time drug-drug interaction and allergy contraindication checking module.
- **Design:** Develop a formulary checking algorithm that integrates with the payer formulary service.
- **Implementation:** Implement the real-time drug-drug interaction and allergy contraindication checking functionality.
- **Implementation:** Develop a user interface for formulary checking and ensure it is integrated with the payer formulary service.
- **Verification:** Perform integration testing between the prescriber interface and the real-time interaction checking module.
- **Verification:** Test formulary checking against a variety of scenarios to ensure compliance with payer policies.
- **Deployment:** Deploy the system in a controlled environment for a pilot phase to validate real-time interaction and formulary checking.
- **Deployment:** Conduct a final UAT with prescribers and pharmacists to ensure all functionalities are working as expected.
- **Maintenance:** Monitor system performance for real-time interaction and formulary checking issues.
- **Maintenance:** Update the system with new formulary data as required by payers.
