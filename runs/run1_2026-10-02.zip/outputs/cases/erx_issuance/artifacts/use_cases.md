# Use cases

## UC-1 Issuing an Electronic Prescription with Interaction and Allergy Checks

- Primary actor: Prescriber
- Realises: FR-ERX-001, FR-ERX-002, FR-ERX-003, FR-ERX-005, FR-ERX-006, FR-ERX-008, FR-ERX-009, FR-ERX-012, FR-ERX-013, FR-ERX-014, FR-ERX-025
- Preconditions: The prescriber has logged into the EHR system.; The patient's active medication list and recorded allergies are available in the system.

Main success scenario:

1. The prescriber selects a patient from the EHR system.
2. The system displays the patient's active medication list and recorded allergies on the same screen as the order being written.
3. The prescriber selects a medication to prescribe.
4. The system performs real-time drug-drug interaction and allergy contraindication checking at the point of ordering.
5. If no interactions or allergies are detected, the system generates a prescription with the required fields.
6. The system sends the prescription details to the community pharmacy for filling.
7. The prescriber reviews the generated prescription and signs it.

Alternate and exception flows:

- If an interaction or allergy is detected, the system displays an alert to the prescriber. The prescriber can override the alert with a documented reason, which is recorded in the system.

Postconditions: The electronic prescription is issued and transmitted to the community pharmacy.; The prescriber has a record of the interaction or allergy alert and any overrides.

## UC-2 Changing an Electronic Prescription

- Primary actor: Prescriber
- Realises: FR-ERX-001, FR-ERX-003, FR-ERX-012, FR-ERX-013, FR-ERX-014, FR-ERX-016, FR-ERX-017, FR-ERX-020, FR-ERX-025
- Preconditions: The prescriber has logged into the EHR system.; An electronic prescription exists for a patient.

Main success scenario:

1. The prescriber selects the prescription to change from the EHR system.
2. The system displays the current prescription details and allows the prescriber to modify them.
3. The prescriber makes necessary changes to the prescription.
4. The system checks for drug-drug interactions and allergies before issuing the changed prescription.
5. If no issues are detected, the system generates a new prescription with the updated fields.
6. The system sends the updated prescription details to the community pharmacy for filling.
7. The prescriber reviews the updated prescription and signs it.

Alternate and exception flows:

- If an interaction or allergy is detected, the system displays an alert to the prescriber. The prescriber can override the alert with a documented reason, which is recorded in the system.

Postconditions: The electronic prescription is changed and transmitted to the community pharmacy.; The prescriber has a record of any interaction or allergy alerts and any overrides.

## UC-3 Cancelling an Electronic Prescription

- Primary actor: Prescriber
- Realises: FR-ERX-025, FR-ERX-028, FR-ERX-034
- Preconditions: The prescriber has logged into the EHR system.; An electronic prescription exists for a patient.

Main success scenario:

1. The prescriber selects the prescription to cancel from the EHR system.
2. The system prompts the prescriber to confirm the cancellation.
3. The prescriber confirms the cancellation.
4. The system generates a cancellation request and sends it to the community pharmacy.
5. The system records the cancellation in the patient's medical record.

Alternate and exception flows:

- If the prescriber cancels the prescription, the system sends a notification to the pharmacy within 90 seconds.

Postconditions: The electronic prescription is cancelled and the pharmacy is informed.; The cancellation is recorded in the patient's medical record.

## UC-4 Formulary Checking and Prescription Issuance

- Primary actor: Prescriber
- Realises: FR-ERX-001, FR-ERX-003, FR-ERX-008, FR-ERX-020, FR-ERX-025
- Preconditions: The prescriber has logged into the EHR system.; The patient's active medication list and recorded allergies are available in the system.

Main success scenario:

1. The prescriber selects a patient from the EHR system.
2. The system displays the patient's active medication list and recorded allergies on the same screen as the order being written.
3. The prescriber selects a medication to prescribe.
4. The system checks the formulary by calling the payer formulary service and continues ordering if it does not answer within 3 seconds.
5. If the formulary check is successful, the system generates a prescription with the required fields.
6. The system sends the prescription details to the community pharmacy for filling.
7. The prescriber reviews the generated prescription and signs it.

Alternate and exception flows:

- If the formulary check fails, the system displays an alert to the prescriber indicating that the medication is not covered by the patient's insurance.

Postconditions: The electronic prescription is issued and transmitted to the community pharmacy.; The prescriber has a record of any formulary check results.

