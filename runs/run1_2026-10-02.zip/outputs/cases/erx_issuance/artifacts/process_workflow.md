# Process workflow — Issuing an Electronic Prescription with Interaction and Allergy Checks

Derived from the main success scenario of the first use case.

```mermaid
flowchart TD
    S0["The prescriber selects a patient from the EHR system."]
    S1["The system displays the patient's active medication list and recorded allergies "]
    S0 --> S1
    S2["The prescriber selects a medication to prescribe."]
    S1 --> S2
    S3["The system performs real-time drug-drug interaction and allergy contraindication"]
    S2 --> S3
    S4["If no interactions or allergies are detected, the system generates a prescriptio"]
    S3 --> S4
    S5["The system sends the prescription details to the community pharmacy for filling."]
    S4 --> S5
    S6["The prescriber reviews the generated prescription and signs it."]
    S5 --> S6
```
