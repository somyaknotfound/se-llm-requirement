# Data requirements

| Requirement | Statement | Acceptance criteria | Sources |
|---|---|---|---|
| NFR-EPCS-005 | The system shall retain a record of every identity proofing and every credential issued. | The system maintains a log of all identity proofing and credential issuance activities, which can be audited. | S-CRED-02; S-CRED-07; S-CRED-08 |
| NFR-EPCS-016 | The system shall digitally sign and archive the signed record of controlled substance prescriptions. | The system must apply a digital signature to the prescription record and store it in an accessible format. | S-COMP-01; S-COMP-07 |
| NFR-EPCS-018 | The system shall generate monthly prescription logs. | The system must produce a report summarizing all prescriptions issued within the last month. | S-COMP-03 |
