# Interface requirements

| Requirement | Statement | Acceptance criteria | Sources |
|---|---|---|---|
| FR-EPCS-002 | The system shall transmit the signed prescription to the pharmacy. | The system must ensure that the signed prescription is transmitted to the pharmacy in a secure and compliant manner. | S-COMP-04 |
