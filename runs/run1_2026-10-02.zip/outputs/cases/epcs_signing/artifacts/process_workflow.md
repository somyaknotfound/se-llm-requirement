# Process workflow — Prescribing Controlled Substances for Multiple Patients

Derived from the main success scenario of the first use case.

```mermaid
flowchart TD
    S0["The prescriber selects multiple patients from the ward-round list."]
    S1["The system displays the patient details and required prescription information."]
    S0 --> S1
    S2["The prescriber reviews and enters the prescription details for each patient."]
    S1 --> S2
    S3["The system signs the prescription within 20 seconds per prescription."]
    S2 --> S3
    S4["The signed prescription is transmitted to the pharmacy."]
    S3 --> S4
```
