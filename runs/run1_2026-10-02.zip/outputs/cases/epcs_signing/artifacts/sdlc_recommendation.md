# SDLC recommendation

**Recommended:** Waterfall (83.3%) — runner-up V-Model. Status: pending approval by project manager, architect, security officer, compliance officer.

| Rank | Model | Suitability | Supporting rules |
|---|---|---|---|
| 1 | Waterfall | 83.3% | R-WF |
| 2 | V-Model | 77.5% | R-V |
| 3 | Hybrid | 71.9% | — |
| 4 | Spiral | 50.0% | — |
| 5 | DevSecOps | 37.5% | — |
| 6 | Agile | 29.2% | — |

## Decision factors (median of both models)

| Factor | Score |
|---|---|
| requirement_instability | 1 |
| regulatory_criticality | 5 |
| security_risk | 5 |
| project_complexity | 3 |
| system_size | 2 |
| legacy_dependence | 1 |
| change_frequency | 1.5 |
| continuous_delivery_need | 1 |
| stakeholder_availability | 4 |
| documentation_rigour | 4.5 |
| schedule_budget_rigidity | 5 |
| formal_verification_need | 4.5 |
| failure_consequence | 5 |

Contested (models differ by 2+ points): stakeholder_availability

**Escalated:** the two models disagree by 2+ points on: stakeholder_availability

## Justification

Waterfall ranks first for this project due to its stable requirements and extensive approvals, which align well with the strict regulatory environment and infrequent change in requirements. The project's critical nature, high security risk, and need for formal verification and validation further support the Waterfall approach. V-Model is the runner-up because it emphasizes rigorous verification and validation, which are crucial given the handling of controlled substances and the need for extensive documentation.

Strongest argument against: The primary counterargument against Waterfall is its rigidity, which may not allow for flexibility in a project with strict regulatory deadlines and the potential need for frequent updates or adjustments to meet compliance requirements.


## Project workflow — Waterfall

| # | Phase | Activities | Roles | Deliverables | Security | Compliance checkpoints | Exit criterion | Approval gate |
|---|---|---|---|---|---|---|---|---|
| 1 | Initiation | Define scope and objectives; Select SDLC and plan | project_manager, product_owner | Project charter; SDLC decision record |  |  | Charter and SDLC decision approved | project_manager, architect, security_officer, compliance_officer (RTM checked) |
| 2 | Requirements | Elicit and analyse requirements; Baseline the SRS; Clinical hazard identification | business_analyst, product_owner, compliance_officer | SRS baseline; Traceability matrix |  | HIPAA risk analysis completed and approved (45 CFR 164.308(a)(1)(ii)(A)) | SRS baselined | product_owner, compliance_officer (RTM checked) |
| 3 | Design | Architecture and detailed design | architect | Design specification | Threat modelling (STRIDE) of the functionality; Security requirements review |  | Design approved | architect, security_officer (RTM checked) |
| 4 | Implementation | Build to the design; Unit test | developer | Code; Unit test results | Static application security testing on every build; Dependency and secret scanning |  | Code complete |  |
| 5 | Verification | Integration and system test against the SRS | tester | Test report | Dynamic application security testing; Penetration test before release |  | All requirements verified |  |
| 6 | Deployment | Release and hand-over; Clinical safety case approved | operations, project_manager | Release notes | Security sign-off | ONC certification testing passed for the applicable 45 CFR 170.315 criteria; Third-party EPCS audit or certification passed before use (21 CFR 1311.300) | Accepted into service | project_manager, clinical_safety_officer, security_officer, compliance_officer (RTM checked) |
| 7 | Maintenance | Corrective maintenance; Change control | operations | Change log | Security monitoring and incident response; Vulnerability patching to an agreed timescale | Security documentation retained for 6 years (45 CFR 164.316(b)(2)(i)); Daily audit-trail analysis with incident reporting within one business day (21 CFR 1311.150); Re-audit when signing functionality changes or every two years (21 CFR 1311.300) | Retirement |  |

```mermaid
flowchart LR
    P0{{"Initiation"}}
    P1{{"Requirements"}}
    P0 --> P1
    P2{{"Design"}}
    P1 --> P2
    P3["Implementation"]
    P2 --> P3
    P4["Verification"]
    P3 --> P4
    P5{{"Deployment"}}
    P4 --> P5
    P6["Maintenance"]
    P5 --> P6
```

## Project-specific activities

- **Initiation:** Identify key stakeholders and their roles in the EPCS system, including DEA compliance officers and pharmacy staff.
- **Initiation:** Conduct a risk assessment to identify potential security threats and vulnerabilities.
- **Requirements:** Develop a detailed risk management plan that includes incident reporting procedures and compliance with DEA regulations.
- **Requirements:** Validate the identity proofing process with DEA compliance officers to ensure it meets regulatory requirements.
- **Design:** Design a two-factor authentication mechanism that integrates with the prescriber's biometric and hard token factors.
- **Design:** Create a prototype of the credential issuance process to validate the workflow with DEA compliance officers.
- **Implementation:** Implement the two-factor authentication mechanism and conduct unit tests to ensure it meets the 20-second signing requirement.
- **Implementation:** Deploy a pilot version of the EPCS system with a small group of prescribers to validate the identity proofing and credential issuance processes.
- **Verification:** Integrate the EPCS system with the hospital's existing e-prescribing module and conduct integration testing.
- **Verification:** Perform a security audit to ensure compliance with FIPS 140-2 Security Level 1 for cryptographic modules.
- **Deployment:** Release the EPCS system to a wider group of prescribers for clinical safety case approval.
- **Deployment:** Train prescribers on the use of two-factor authentication and the signing process.
- **Maintenance:** Monitor system performance and address any issues related to two-factor authentication or signing function.
- **Maintenance:** Perform regular audits of the credentialing process to ensure compliance with DEA regulations.
