# Use cases

## UC-1 Prescribing Controlled Substances for Multiple Patients

- Primary actor: Prescriber
- Realises: FR-EPCS-001, FR-EPCS-002, FR-EPCS-003, FR-EPCS-004
- Preconditions: The prescriber has access to the EPCS module.; The prescriber has completed identity proofing and credential issuance.; The prescriber is logged into the system with appropriate permissions.

Main success scenario:

1. The prescriber selects multiple patients from the ward-round list.
2. The system displays the patient details and required prescription information.
3. The prescriber reviews and enters the prescription details for each patient.
4. The system signs the prescription within 20 seconds per prescription.
5. The signed prescription is transmitted to the pharmacy.

Alternate and exception flows:

- If the prescriber needs to make changes, they can edit the prescription before signing.
- If a prescription cannot be signed due to missing information, the system prompts the prescriber to complete it.

Postconditions: The prescriptions are stored in the system with digital signatures.; The pharmacy receives the signed prescriptions.; An audit trail is created for each prescription.

## UC-2 Transmitting Signed Prescriptions to the Pharmacy

- Primary actor: System
- Realises: FR-EPCS-002
- Preconditions: The prescriber has signed a prescription.; The pharmacy is set up as a valid recipient.

Main success scenario:

1. The system detects the signed prescription.
2. The system checks if the pharmacy is a valid recipient.
3. The system transmits the signed prescription to the pharmacy.
4. The pharmacy receives the prescription.

Alternate and exception flows:

- If the pharmacy is not a valid recipient, the system logs the error and notifies the prescriber.
- If the transmission fails, the system retries the transmission up to three times.

Postconditions: The pharmacy has received the signed prescription.; The system logs the transmission attempt.

## UC-3 Ensuring Digital Signature Integrity and Verification

- Primary actor: System
- Realises: FR-EPCS-003, FR-EPCS-004
- Preconditions: The prescriber has signed a prescription.; The system has the prescriber's digital signature information.

Main success scenario:

1. The system verifies the prescriber's digital signature.
2. The system stores the verified signature with the prescription record.

Alternate and exception flows:

- If the signature verification fails, the system logs the error and prompts the prescriber to re-sign.
- If the prescriber's credentials are invalid, the system denies access and logs the attempt.

Postconditions: The prescription record is stored with a verified digital signature.; Any failed attempts are logged for audit purposes.

## UC-4 Generating and Maintaining Audit Trails

- Primary actor: System
- Realises: FR-EPCS-005
- Preconditions: The system is operational.; Prescriptions are being signed and transmitted.

Main success scenario:

1. The system generates an audit trail for each prescription.
2. The system stores the audit trail with the prescription record.
3. The system provides daily analysis of the audit trails.
4. The system allows monthly prescription logs to be generated.

Alternate and exception flows:

- If the audit trail generation fails, the system logs the error and attempts to recover.
- If the system encounters an incident, it generates a report and notifies the appropriate parties.

Postconditions: The system maintains a complete audit trail for each prescription.; Daily analysis reports are available for review.; Monthly prescription logs are generated and stored.

