# Process workflow — Patient Requests Prescription Renewal

Derived from the main success scenario of the first use case.

```mermaid
flowchart TD
    S0["The system reminds the patient 7 days before their medication supply runs out (F"]
    S1["The patient taps on the reminder to request a prescription renewal (FR-REF-003, "]
    S0 --> S1
    S2["The system sends a renewal request to the prescriber for approval without prompt"]
    S1 --> S2
    S3["The prescriber approves or denies the renewal request."]
    S2 --> S3
    S4["If approved, the pharmacy prepares the medication and notifies the patient when "]
    S3 --> S4
```
