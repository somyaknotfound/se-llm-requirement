# SDLC recommendation

**Recommended:** Waterfall (62.5%) — runner-up V-Model. Status: pending approval by project manager, architect, security officer, compliance officer.

| Rank | Model | Suitability | Supporting rules |
|---|---|---|---|
| 1 | Waterfall | 62.5% | R-WF |
| 2 | V-Model | 60.0% | — |
| 3 | Hybrid | 59.4% | — |
| 4 | DevSecOps | 54.2% | — |
| 5 | Agile | 52.1% | — |
| 6 | Spiral | 37.5% | — |

## Decision factors (median of both models)

| Factor | Score |
|---|---|
| requirement_instability | 1.5 |
| regulatory_criticality | 4 |
| security_risk | 4 |
| project_complexity | 2.5 |
| system_size | 2 |
| legacy_dependence | 1 |
| change_frequency | 2 |
| continuous_delivery_need | 3.5 |
| stakeholder_availability | 4.5 |
| documentation_rigour | 4 |
| schedule_budget_rigidity | 3.5 |
| formal_verification_need | 3.5 |
| failure_consequence | 3.5 |

Contested (models differ by 2+ points): regulatory_criticality, security_risk, continuous_delivery_need, documentation_rigour, schedule_budget_rigidity, formal_verification_need, failure_consequence

**Escalated:** near tie: Waterfall 62.5% vs V-Model 60.0%; the two models disagree by 2+ points on: regulatory_criticality, security_risk, continuous_delivery_need, documentation_rigour, schedule_budget_rigidity, formal_verification_need, failure_consequence

## Justification

Waterfall ranks first for this project due to its stable requirements and extensive approvals, which align well with the moderate requirement instability and frequent changes. The V-Model is the runner-up as it also emphasizes detailed planning and documentation, fitting the high stakeholder availability and moderate documentation rigour. These factors support a sequential approach where detailed upfront planning can be effectively managed.

Strongest argument against: While Waterfall provides stability, its rigidity may not accommodate the frequent changes and usability tuning required by the project. The need for continuous delivery and moderate change frequency suggest a more flexible approach might be more suitable.


## Project workflow — Waterfall

| # | Phase | Activities | Roles | Deliverables | Security | Compliance checkpoints | Exit criterion | Approval gate |
|---|---|---|---|---|---|---|---|---|
| 1 | Initiation | Define scope and objectives; Select SDLC and plan | project_manager, product_owner | Project charter; SDLC decision record |  |  | Charter and SDLC decision approved | project_manager, architect, security_officer, compliance_officer (RTM checked) |
| 2 | Requirements | Elicit and analyse requirements; Baseline the SRS; Clinical hazard identification | business_analyst, product_owner, compliance_officer | SRS baseline; Traceability matrix |  | HIPAA risk analysis completed and approved (45 CFR 164.308(a)(1)(ii)(A)) | SRS baselined | product_owner, compliance_officer (RTM checked) |
| 3 | Design | Architecture and detailed design | architect | Design specification | Threat modelling (STRIDE) of the functionality; Security requirements review |  | Design approved | architect, security_officer (RTM checked) |
| 4 | Implementation | Build to the design; Unit test | developer | Code; Unit test results | Static application security testing on every build; Dependency and secret scanning |  | Code complete |  |
| 5 | Verification | Integration and system test against the SRS | tester | Test report | Dynamic application security testing; Penetration test before release |  | All requirements verified |  |
| 6 | Deployment | Release and hand-over; Clinical safety case approved | operations, project_manager | Release notes | Security sign-off | ONC certification testing passed for the applicable 45 CFR 170.315 criteria | Accepted into service | project_manager, clinical_safety_officer, security_officer, compliance_officer (RTM checked) |
| 7 | Maintenance | Corrective maintenance; Change control | operations | Change log | Security monitoring and incident response; Vulnerability patching to an agreed timescale | Security documentation retained for 6 years (45 CFR 164.316(b)(2)(i)) | Retirement |  |

```mermaid
flowchart LR
    P0{{"Initiation"}}
    P1{{"Requirements"}}
    P0 --> P1
    P2{{"Design"}}
    P1 --> P2
    P3["Implementation"]
    P2 --> P3
    P4["Verification"]
    P3 --> P4
    P5{{"Deployment"}}
    P4 --> P5
    P6["Maintenance"]
    P5 --> P6
```

## Project-specific activities

- **Initiation:** Identify key stakeholders and their roles in the project.
- **Initiation:** Conduct a risk assessment focusing on patient safety and data privacy.
- **Requirements:** Conduct user interviews with patients and caregivers to validate the reminder functionality.
- **Requirements:** Develop a prototype of the reminder feature for initial user feedback.
- **Design:** Create a high-fidelity prototype of the reminder and renewal request screens.
- **Design:** Perform a design review with clinical experts to ensure compliance with medical standards.
- **Implementation:** Develop the backend logic for generating and sending reminders.
- **Implementation:** Implement the frontend screens for medication reminders and renewal requests.
- **Verification:** Perform integration testing to ensure the reminder and renewal request features work as expected.
- **Verification:** Conduct system testing with a subset of patients to validate the functionality.
- **Deployment:** Deploy the app to a small group of patients for a pilot release.
- **Deployment:** Monitor the system for any issues and gather feedback from users.
- **Maintenance:** Monitor the app for bugs and user feedback.
- **Maintenance:** Update the app based on user feedback and new requirements.
