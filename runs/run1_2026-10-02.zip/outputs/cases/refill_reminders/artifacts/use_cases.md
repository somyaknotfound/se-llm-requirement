# Use cases

## UC-1 Patient Requests Prescription Renewal

- Primary actor: Patient
- Realises: FR-REF-001, FR-REF-002, FR-REF-003, FR-REF-004, FR-REF-005, FR-REF-007, FR-REF-009, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-016, FR-REF-018, FR-REF-019, FR-REF-020, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-030, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037
- Preconditions: The patient has a prescription in the system.; The patient has consented to receive reminders and renewals through the app.

Main success scenario:

1. The system reminds the patient 7 days before their medication supply runs out (FR-REF-001, FR-REF-028, FR-REF-039).
2. The patient taps on the reminder to request a prescription renewal (FR-REF-003, FR-REF-005, FR-REF-016, FR-REF-020, FR-REF-040).
3. The system sends a renewal request to the prescriber for approval without prompting the patient (FR-REF-030).
4. The prescriber approves or denies the renewal request.
5. If approved, the pharmacy prepares the medication and notifies the patient when it is ready for pickup (FR-REF-002, FR-REF-004, FR-REF-007, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-018, FR-REF-019, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037).

Alternate and exception flows:

- If the prescriber denies the renewal request, the patient is notified and can try again or contact their healthcare provider (FR-REF-029).

Postconditions: The patient's medication supply is renewed if approved.; The patient is informed of the status of their renewal request.

## UC-2 Caregiver Acts on Patient's Behalf

- Primary actor: Caregiver
- Realises: FR-REF-001, FR-REF-002, FR-REF-004, FR-REF-007, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-018, FR-REF-019, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-030, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037
- Preconditions: The caregiver has been granted proxy access by the patient.; The patient has consented to receive reminders and renewals through the app.

Main success scenario:

1. The system reminds the patient 7 days before their medication supply runs out (FR-REF-001, FR-REF-028, FR-REF-039).
2. The caregiver taps on the reminder to act on the patient's behalf (FR-REF-011, FR-REF-022, FR-REF-042).
3. The system sends a renewal request to the prescriber for approval without prompting the patient (FR-REF-030).
4. The prescriber approves or denies the renewal request.
5. If approved, the pharmacy prepares the medication and notifies the patient when it is ready for pickup (FR-REF-002, FR-REF-004, FR-REF-007, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-018, FR-REF-019, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037).

Alternate and exception flows:

- If the prescriber denies the renewal request, the patient is notified and can try again or contact their healthcare provider (FR-REF-029).

Postconditions: The patient's medication supply is renewed if approved.; The patient is informed of the status of their renewal request.

## UC-3 Patient Checks Renewal Request Status

- Primary actor: Patient
- Realises: FR-REF-001, FR-REF-003, FR-REF-005, FR-REF-016, FR-REF-020, FR-REF-028, FR-REF-030, FR-REF-033, FR-REF-039
- Preconditions: The patient has a prescription in the system.; The patient has consented to receive reminders and renewals through the app.

Main success scenario:

1. The system reminds the patient 7 days before their medication supply runs out (FR-REF-001, FR-REF-028, FR-REF-039).
2. The patient taps on the reminder to request a prescription renewal (FR-REF-003, FR-REF-005, FR-REF-016, FR-REF-020, FR-REF-040).
3. The system sends a renewal request to the prescriber for approval without prompting the patient (FR-REF-030).
4. The patient checks the status of their renewal request through the app (FR-REF-033, FR-REF-039).

Alternate and exception flows:

- If the prescriber denies the renewal request, the patient is notified and can try again or contact their healthcare provider (FR-REF-029).

Postconditions: The patient knows the status of their renewal request.

## UC-4 Patient Checks Medication Readiness

- Primary actor: Patient
- Realises: FR-REF-001, FR-REF-002, FR-REF-004, FR-REF-007, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-018, FR-REF-019, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037
- Preconditions: The patient has a prescription in the system.; The patient has consented to receive reminders and renewals through the app.

Main success scenario:

1. The system reminds the patient 7 days before their medication supply runs out (FR-REF-001, FR-REF-028, FR-REF-039).
2. The patient taps on the reminder to request a prescription renewal (FR-REF-003, FR-REF-005, FR-REF-016, FR-REF-020, FR-REF-040).
3. The system sends a renewal request to the prescriber for approval without prompting the patient (FR-REF-030).
4. The pharmacy prepares the medication and notifies the patient when it is ready for pickup (FR-REF-002, FR-REF-004, FR-REF-007, FR-REF-010, FR-REF-011, FR-REF-012, FR-REF-013, FR-REF-014, FR-REF-015, FR-REF-018, FR-REF-019, FR-REF-021, FR-REF-026, FR-REF-027, FR-REF-029, FR-REF-031, FR-REF-034, FR-REF-035, FR-REF-037).
5. The patient checks the status of their medication readiness through the app (FR-REF-034, FR-REF-039).

Alternate and exception flows:

- If the prescriber denies the renewal request, the patient is notified and can try again or contact their healthcare provider (FR-REF-029).

Postconditions: The patient knows when their medication is ready for pickup.

