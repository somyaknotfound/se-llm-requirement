# User stories

## FR-REF-001

As a system, I want to remind the patient 7 days before any of their medications runs out, so that they can prepare for refills.

```gherkin
Given the system has access to the patient's medication schedule
When the system detects that a medication is due to run out in 7 days
Then the system sends a reminder to the patient 7 days before each medication's supply is expected to run out
```

## FR-REF-002

As a system, I want to notify the patient to reorder their medication on time to ensure they do not run out, so that they can maintain their medication supply.

```gherkin
Given the system has detected that a patient's medication is running low
When the patient receives a notification reminding them to reorder their medication
Then the requirement is met if the patient is reminded to reorder their medication on time
```

## FR-REF-003

As a patient, I want to request a prescription renewal with one tap from the reminder after authenticating myself, so that I can easily manage my medications.

```gherkin
Given the patient has received a reminder notification for a medication refill
When the patient taps on the reminder notification and authenticates themselves
Then the system initiates a prescription renewal request
```

## FR-REF-004

As a system, I want to notify the patient when their medication is ready for pickup at the pharmacy, so that they can collect it promptly.

```gherkin
Given the patient's medication has been prepared at the pharmacy
When the system detects that the medication is ready for pickup
Then the system sends a notification to the patient informing them that their medication is ready for pickup
```

## FR-REF-005

As a patient, I want to reorder my medication from the reminder by tapping once, which sends a request for renewal, so that I can easily manage my medications.

```gherkin
Given the patient has received a reminder notification for a medication refill
When the patient taps on the reminder notification
Then the system sends a request for renewal of the medication
```

## FR-REF-006

As a system, I want to name the medication in the reminder to help the patient identify which one to reorder, so that they can easily manage their medications.

```gherkin
Given the patient has received a reminder notification for a specific medication
When the reminder notification includes the name of the medication
Then the reminder notification includes the name of the medication that needs to be reordered, like 'Your insulin is running low'
```

## FR-REF-007

As a patient, I want the system to notify me when my medication is ready for pickup at the pharmacy, so that I can reorder my medication on time and ensure no missed doses.

```gherkin
Given the patient has an upcoming medication refill due, When the pharmacy marks the medication as ready for pickup, Then the system sends a notification to the patient's registered device.
```

## FR-REF-009

As a patient, I want the system to allow me to request a prescription renewal if I have given consent in the app, so that my medications can be refilled without delay.

```gherkin
Given the patient has given consent for prescription renewals in the app, When the patient initiates a prescription renewal request through the app, Then the request is routed to the prescriber for approval.
Given the patient has not given consent for prescription renewals in the app, When the patient attempts to initiate a prescription renewal request through the app, Then the system denies the request and prompts the patient to provide consent.
```

## FR-REF-010

As a patient, I want the system to notify me when the pharmacy has the medication ready, so that I can withdraw my access at any time and stop receiving notifications immediately.

```gherkin
Given the patient has given consent for medication notifications, When the pharmacy marks the medication as ready for pickup, Then the system sends a notification to the patient's registered device.
Given the patient has withdrawn their access, When the pharmacy marks the medication as ready for pickup, Then the system does not send a notification to the patient's registered device.
```

## FR-REF-011

As a caregiver, I want the system to allow me to act on the patient's behalf with their consent, so that I can request medication refills for them.

```gherkin
Given the patient has given explicit consent within the app for the caregiver to act on their behalf, When the caregiver requests a medication refill through the app, Then the system processes the request and sends it to the pharmacy for approval.
```

## FR-REF-012

As a caregiver, I want the system to allow me to withdraw access for a patient at any time, so that the patient's access is immediately revoked in the app.

```gherkin
Given the caregiver has access to act on the patient's behalf, When the caregiver revokes their access through the app, Then the system immediately stops processing requests initiated by the caregiver.
```

## FR-REF-013

As a patient, I want the system to remind me before my medication supply runs out, so that I can reorder my medications in time.

```gherkin
Given the patient has an upcoming medication refill due, When the system calculates that the patient's medication supply will run out within 30 days, Then the system sends a reminder to the patient's registered device.
Given the system has sent a reminder to the patient, When the patient reorders their medication before the supply runs out, Then the system marks the refill as completed and updates the patient's record.
```

## FR-REF-014

As a system, I want to automatically generate a renewal request when a patient's medication supply is expected to run out, so that the prescriber can approve it in time.

```gherkin
Given a patient with an upcoming medication supply expiration date, When the system detects the expiration, Then a renewal request should be generated for the prescriber to approve.
```

## FR-REF-015

As a system, I want to notify patients when the pharmacy has their medication ready, so that they can pick it up or have it delivered.

```gherkin
Given a patient with a filled prescription, When the pharmacy marks the prescription as ready, Then the system should send a notification to the patient.
```

## FR-REF-016

As a patient, I want to request a prescription renewal through the app, so that my medication supply can be extended.

```gherkin
Given a patient logged into the app, When the patient requests a prescription renewal, Then the system should record this action for future reference.
```

## FR-REF-017

As a system, I want to allow caregivers to act on behalf of patients with consent, so that medication requests can be managed by authorized individuals.

```gherkin
Given a patient who has given explicit consent for a caregiver to manage their medication requests, When the caregiver uses the app to manage these requests, Then the system should record the actions taken by the caregiver.
```

## FR-REF-018

As a system, I want to support A/B testing of reminder wording and timing based on patient feedback, so that we can determine the most effective reminders.

```gherkin
Given the system is conducting an A/B test, When different reminder messages and timings are sent to patients, Then the system should track patient engagement and medication supply outcomes.
```

## FR-REF-019

As a system, I want to remind patients before their medication supply runs out, so that they can request a refill in time.

```gherkin
Given a patient with an upcoming medication supply expiration date, When the system detects the expiration, Then the patient should receive a notification at least one week before the supply runs out.
```

## FR-REF-020

As a patient, I want to request a prescription renewal through the app, so that the system can check my EHR and notify me if a renewal request has been sent after confirming I'm still taking the medication.

```gherkin
Given a patient who needs to renew their prescription
When the patient submits a renewal request through the app
Then the system checks the EHR to see if a renewal request has been sent and notifies the patient if they are still taking the medication
```

## FR-REF-021

As a patient, I want to receive a notification when my medication is ready for pickup at the pharmacy, so that I can plan to visit the pharmacy.

```gherkin
Given a patient whose medication is ready at the pharmacy
When the system processes the prescription and marks it as ready
Then the system sends a notification to the patient's app indicating that their medication is ready for pickup
```

## FR-REF-022

As a caregiver, I want to act on behalf of the patient with their consent, so that I can submit a renewal request on their behalf and ensure they receive their medication.

```gherkin
Given a patient who has given consent for a caregiver to act on their behalf
When the caregiver submits a renewal request through the app
Then the system processes the request without notifying the patient, and waits for caregiver approval before finalizing the request
```

## FR-REF-023

As a system user, I want to ensure that the system does not make prescribing decisions, so that it only provides reminders and routes requests to the prescriber for approval.

```gherkin
Given a patient's prescription renewal request
When the system processes the request
Then the system only provides reminders and routes the request to the prescriber for approval without generating or modifying prescriptions
```

## FR-REF-025

As a patient, I want to request a prescription renewal through the app, so that the system can process my request.

```gherkin
Given a patient who needs to renew their prescription
When the patient submits a renewal request through the app
Then the system processes the request without specifying an observable outcome or threshold for verification
```

## FR-REF-026

As a patient, I want to receive a notification when my medication is ready for pickup at the pharmacy, so that I can plan to visit the pharmacy.

```gherkin
Given a patient whose medication is ready at the pharmacy
When the system processes the prescription and marks it as ready
Then the system sends a notification to the patient's app indicating that their medication is ready for pickup
```

## FR-REF-027

As a system, I want to allow patients to sign in through the network's OpenID Connect provider with multi-factor authentication at enrolment, so that patients can securely access their medical records.

```gherkin
Given a patient who has enrolled and provided their OpenID Connect credentials, When the patient attempts to log in, Then the system should prompt for multi-factor authentication and grant access upon successful verification.
Given a patient who has not yet enrolled, When they attempt to sign up using OpenID Connect, Then the system should guide them through the enrolment process including multi-factor authentication.
```

## FR-REF-028

As a system, I want to remind the patient one week before their medication supply runs out, so that patients do not run out of their medications.

```gherkin
Given a patient with an upcoming medication refill, When the system detects that the medication supply is running low, Then it should send a reminder to the patient one week before the supply is expected to run out.
Given a patient who has just received a medication refill, When the system calculates the next refill date, Then it should schedule a reminder one week before the refill date.
```

## FR-REF-029

As a patient, I want to request a prescription renewal, so that my medication supply is not interrupted.

```gherkin
Given a patient who has a pending prescription renewal, When the patient requests a renewal through the system, Then the system should record the request and track its status.
Given 100 eligible patients, When 30% of them use the renewal request feature within six months, Then the requirement is considered met.
```

## FR-REF-030

As a system, I want to route the prescription renewal request to the prescriber for approval without prompting the patient, so that the process is streamlined.

```gherkin
Given a patient who has requested a prescription renewal, When the system receives the request, Then it should automatically route it to the prescriber for approval without requiring any further action from the patient.
Given a prescriber who has received a renewal request, When they review and approve it, Then the system should update the patient's record accordingly.
```

## FR-REF-031

As a system, I want to notify the patient when the pharmacy has the medication ready, so that patients are informed about their medication availability.

```gherkin
Given a patient who has requested a prescription renewal, When the pharmacy prepares the medication, Then the system should notify the patient that their medication is ready for pickup or delivery.
Given 1000 notifications sent to patients, When 95% of them are received and acknowledged by the patients, Then the requirement is considered met.
```

## FR-REF-032

As a system, I want to allow caregivers to act on behalf of the patient with the patient's consent, so that caregivers can manage medication refills.

```gherkin
Given a patient who has given explicit consent for their caregiver to manage medication refills, When the caregiver logs in using their credentials, Then they should be able to perform actions related to the patient's medication refills.
Given a caregiver who has been granted access, When they request a prescription renewal on behalf of the patient, Then the system should route the request to the prescriber for approval.
```

## FR-REF-033

As a patient, I want to check if my prescription renewal request has been received, so that I can be assured it is being processed.

```gherkin
Given the patient has initiated a prescription renewal request
When the system processes the request
Then the system should display the status as 'Received' in the patient's dashboard
```

## FR-REF-034

As a patient, I want to check if the pharmacy has my medication ready, so that I can plan when to pick it up or have it delivered.

```gherkin
Given the patient's medication is ready for pickup or delivery at the pharmacy
When the patient checks the status of their medication
Then the system should display the status as 'Ready for Pickup' or 'Ready for Delivery'
```

## FR-REF-035

As a system, I want to remind the patient before their medication supply runs out, so that they can refill their prescription in time.

```gherkin
Given the system has the patient's medication supply information
When the medication supply is expected to run out within 7 days
Then the system should send a notification to the patient's mobile app
```

## FR-REF-036

As a patient, I want to request a prescription renewal, so that I can ensure my medication supply is not interrupted.

```gherkin
Given the patient has a need for a prescription renewal
When the patient initiates a prescription renewal request through the mobile app
Then the system should track the number of patients who use this feature and ensure at least 30% usage within six months
```

## FR-REF-037

As a system, I want to notify the patient when the pharmacy has their medication ready, so that the patient can plan accordingly.

```gherkin
Given the pharmacy has the patient's medication ready for pickup or delivery
When the patient checks the status of their medication
Then the system should send a notification to the patient's mobile app
```

## FR-REF-038

As a system, I want to allow a caregiver to act on the patient's behalf with the patient's consent, so that the caregiver can assist in managing the patient's medication.

```gherkin
Given the patient has granted consent for a specific caregiver to access their account
When the caregiver logs into the patient's account
Then the system should allow the caregiver to perform actions such as requesting prescription renewals on behalf of the patient
```

## FR-REF-039

As a system, I want to remind the patient before their medication supply runs out, so that the patient does not run out of medication.

```gherkin
Given the system has access to the patient's medication supply schedule
When the system detects that the medication supply is expected to run out in 7 days
Then the system sends a reminder to the patient
```

## FR-REF-040

As a patient, I want to request a prescription renewal, so that my medication supply can be extended if needed.

```gherkin
Given the system has a feature for requesting prescription renewals
When 30% of eligible patients use this feature within six months
Then the system tracks and measures the usage against the overall patient population
```

## FR-REF-041

As a system, I want to notify the patient when the pharmacy has their medication ready, so that the patient can pick up their medication promptly.

```gherkin
Given the system has access to the pharmacy's medication readiness status
When the pharmacy has the patient's medication ready
Then the system sends a notification to the patient
```

## FR-REF-042

As a system, I want to allow a caregiver to act on the patient's behalf with the patient's consent, so that the caregiver can manage the patient's medication schedule.

```gherkin
Given the system has a feature for proxy access
When a patient consents to a caregiver acting on their behalf
Then the system records the proxy access and allows the caregiver to perform actions on the patient's behalf
And the system logs all actions taken by the caregiver
```

## FR-REF-043

As a system, I want to not make prescribing decisions, so that the medical professionals retain control over medication prescriptions.

```gherkin
Given the system provides reminders, requests, and notifications
When the system does not generate or modify prescriptions
Then the system only performs its designated functions
```

## FR-REF-044

As a system, I want to require a review by the health information management team before granting proxy access for patients aged 13-17, so that the patient's privacy and safety are protected.

```gherkin
Given the system has a feature for granting proxy access
When a patient aged 13-17 requests proxy access
Then the system requires a review by the health information management team before granting the access
```

