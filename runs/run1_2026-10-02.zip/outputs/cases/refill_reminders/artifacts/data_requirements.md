# Data requirements

| Requirement | Statement | Acceptance criteria | Sources |
|---|---|---|---|
| FR-REF-005 | The system shall allow the patient to reorder their medication from the reminder by tapping once, which sends a request for renewal. | The patient can reorder their medication through the system by tapping once on the reminder, sending a request for renewal. | S-PAT-02; S-PAT-12; S-PAT-17 |
